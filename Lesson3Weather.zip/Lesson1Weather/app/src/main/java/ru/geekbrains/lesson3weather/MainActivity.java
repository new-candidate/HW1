
package com.example.lesson1weather;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private String cityDataKey = "cityDataKey";
    private String textCity;
//    private TextView viewCity;




//    private TextView textView;
//    private boolean autolocation_set;
//    private String  City = null;

//    Убираем сохарнение чекбоксов
//    private CheckBox mwind_velocity;
//    private boolean mywind_velocity;
//    private String winddatakey = "windatakey";
//    private String airdatakey = "airdatakey";



//    @Override
//    public <T extends View> T findViewById(int id) {
//        return super.findViewById(R.id.textView);
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.city_choice);
        String instanceState;
        if (savedInstanceState == null) {
            instanceState = "Первый запуск!";
        } else {
            instanceState = "Повторный запуск!";
        }
        Toast.makeText(getApplicationContext(), instanceState + " - onCreate()", Toast.LENGTH_SHORT).show();
        Log.d("STATE", " - onCreate()");
//        initViews();


    }
//    private void initViews() {
//        TextView viewCity = findViewById(R.id.city1);
//        // Поле счетчика        ​
//        viewCity.setText(textCity);
//        // Выводим счетчик на экран



        //    Убираем сохарнение чекбоксов
//        mwind_velocity = findViewById(R.id.wind_velocity);
//        if (mwind_velocity.isChecked()) {
//            mywind_velocity = true;
//        }



    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(getApplicationContext(), "onStart()", Toast.LENGTH_SHORT).show();
        Log.d("STATE", "onStart()");
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle saveInstanceState) {
        super.onRestoreInstanceState(saveInstanceState);

        textCity = saveInstanceState.getString("cityDataKey");
//        viewCity.setText(textCity);
        Toast.makeText(getApplicationContext(), "Повторный запуск!! - onRestoreInstanceState()", Toast.LENGTH_SHORT).show();
        Log.d("STATE", "Повторный запуск!! - onRestoreInstanceState()");


    }


    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(getApplicationContext(), "onResume()", Toast.LENGTH_SHORT).show();
        Log.d("STATE", "onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(getApplicationContext(), "onPause()", Toast.LENGTH_SHORT).show();
        Log.d("STATE", "onPause()");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle saveInstanceState) {
        super.onSaveInstanceState(saveInstanceState);
        Toast.makeText(getApplicationContext(), "onSaveInstanceState()", Toast.LENGTH_SHORT).show();
        Log.d("STATE", "onSaveInstanceState()");
        saveInstanceState.putString(cityDataKey, textCity);

//        String text = textView.getText().toString();

        //    Убираем сохарнение чекбоксов
//        saveInstanceState.putBoolean(winddatakey, mywind_velocity);
//
//        super.onSaveInstanceState(saveInstanceState);
//
//        saveInstanceState.putSerializable(winddatakey, DataContainer.getInstance());


//        mwind_velocity = wind_velocity.isChecked();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(getApplicationContext(), "onStop()", Toast.LENGTH_SHORT).show();
        Log.d("STATE", "onStop()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(getApplicationContext(), "onRestart()", Toast.LENGTH_SHORT).show();
        Log.d("STATE", "onRestart()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("STATE", "onDestroy()");
    }






    //        initViews();
//        setColorOfTextView();
//    }


//    private void initViews() {
//        textView = findViewById(R.id.cityTextView);
//    }





//        int orientation = getResources().getConfiguration().orientation;
//        if (orientation != Configuration.ORIENTATION_LANDSCAPE) {
//            beginnerSwitch = findViewById(R.id.switch1);
//        }
//}






//    private void setColorOfTextView() {
//        //String appName = getString(R.string.app_name);
//        textView.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
//    }
}













//package com.example.lesson1weather;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//
//import android.os.Bundle;
//import android.util.Log;
//import android.widget.Toast;
//
//public class MainActivity extends AppCompatActivity {
////    private TextView textView;
////    private boolean autolocation_set;
////    private String  City = null;
//
////    Убираем сохарнение чекбоксов
////    private CheckBox mwind_velocity;
////    private boolean mywind_velocity;
////    private String winddatakey = "windatakey";
////    private String airdatakey = "airdatakey";
//
//
//
////    @Override
////    public <T extends View> T findViewById(int id) {
////        return super.findViewById(R.id.textView);
////    }
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.city_choice);
//        String instanceState;
//        if (savedInstanceState == null) {
//            instanceState = "Первый запуск!";
//        } else {
//            instanceState = "Повторный запуск!";
//        }
//        Toast.makeText(getApplicationContext(), instanceState + " - onCreate()", Toast.LENGTH_SHORT).show();
//        Log.d("STATE", " - onCreate()");
//        initViews();
//
//
//    }
//    private void initViews() {
//        //    Убираем сохарнение чекбоксов
////        mwind_velocity = findViewById(R.id.wind_velocity);
////        if (mwind_velocity.isChecked()) {
////            mywind_velocity = true;
////        }
//
//    }
//
//    @Override
//    protected void onStart() {
//        super.onStart();
//        Toast.makeText(getApplicationContext(), "onStart()", Toast.LENGTH_SHORT).show();
//        Log.d("STATE", "onStart()");
//    }
//
//    @Override
//    protected void onRestoreInstanceState(@NonNull Bundle saveInstanceState) {
//        super.onRestoreInstanceState(saveInstanceState);
//        Toast.makeText(getApplicationContext(), "Повторный запуск!! - onRestoreInstanceState()", Toast.LENGTH_SHORT).show();
//        Log.d("STATE", "Повторный запуск!! - onRestoreInstanceState()");
//
//    }
//
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        Toast.makeText(getApplicationContext(), "onResume()", Toast.LENGTH_SHORT).show();
//        Log.d("STATE", "onResume()");
//    }
//
//    @Override
//    protected void onPause() {
//        super.onPause();
//        Toast.makeText(getApplicationContext(), "onPause()", Toast.LENGTH_SHORT).show();
//        Log.d("STATE", "onPause()");
//    }
//
//    @Override
//    protected void onSaveInstanceState(@NonNull Bundle saveInstanceState) {
//        super.onSaveInstanceState(saveInstanceState);
//        Toast.makeText(getApplicationContext(), "onSaveInstanceState()", Toast.LENGTH_SHORT).show();
//        Log.d("STATE", "onSaveInstanceState()");
//
////        String text = textView.getText().toString();
//
//        //    Убираем сохарнение чекбоксов
////        saveInstanceState.putBoolean(winddatakey, mywind_velocity);
////
////        super.onSaveInstanceState(saveInstanceState);
////
////        saveInstanceState.putSerializable(winddatakey, DataContainer.getInstance());
//
//
////        mwind_velocity = wind_velocity.isChecked();
//    }
//
//    @Override
//    protected void onStop() {
//        super.onStop();
//        Toast.makeText(getApplicationContext(), "onStop()", Toast.LENGTH_SHORT).show();
//        Log.d("STATE", "onStop()");
//    }
//
//    @Override
//    protected void onRestart() {
//        super.onRestart();
//        Toast.makeText(getApplicationContext(), "onRestart()", Toast.LENGTH_SHORT).show();
//        Log.d("STATE", "onRestart()");
//    }
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        Log.d("STATE", "onDestroy()");
//    }
//
//
//
//
//
//
//        //        initViews();
////        setColorOfTextView();
////    }
//
//
////    private void initViews() {
////        textView = findViewById(R.id.cityTextView);
////    }
//
//
//
//
//
////        int orientation = getResources().getConfiguration().orientation;
////        if (orientation != Configuration.ORIENTATION_LANDSCAPE) {
////            beginnerSwitch = findViewById(R.id.switch1);
////        }
////}
//
//
//
//
//
//
////    private void setColorOfTextView() {
////        //String appName = getString(R.string.app_name);
////        textView.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
////    }
//}
